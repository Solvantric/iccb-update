import type { Metadata } from "next";
import { ProfilePage } from "@/components/dashboard/admin/ProfilePage";

export const metadata: Metadata = { title: "Profile" };
export default function Page() {
  return <ProfilePage />;
}
